package ivanc.swap;

/**
 * Created by ivanc on 12/3/2016.
 */

public class NavigationDrawerItem {
    private String name;

    public NavigationDrawerItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
